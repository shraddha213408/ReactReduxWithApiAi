import axios from 'axios';
export const FETCH_POSTS = 'FETCH_POSTS';
export const CREATE_POST = 'CREATE_POST';
export const SHOW_POST = 'SHOW_POST';
export const DELETE_POST = 'DELETE_POST';
export const FETCH_CHAT = 'FETCH_CHAT';

const ROOT_URL = 'http://reduxblog.herokuapp.com/api';
const API_KEY = '?key=987abc234def';
const CLIENT_KEY = '68ee692e3ccb417d9f5118a3c40a3791'; // your client key goes here
const API_AI_URL = 'https://api.api.ai/api/query?v=20150910';

export function fetchPost() {
	const request = axios.get(`${ROOT_URL}/posts${API_KEY}`)

	return {
		type: FETCH_POSTS,
		payload: request
	};
}

export function createPost(props) {
	const request = axios.post(`${ROOT_URL}/posts${API_KEY}`, props)

	return {
		type: CREATE_POST,
		payload: request
	};
}

export function showPost(id) {
	const request = axios.get(`${ROOT_URL}/posts/${id}${API_KEY}`)

	return {
		type: SHOW_POST,
		payload: request
	};
}

export function deletePost(id) {
	const request = axios.delete(`${ROOT_URL}/posts/${id}${API_KEY}`)

	return {
		type: DELETE_POST,
		payload: request
	};
}

export function getChat(query){
	const request = axios({
		method: 'post',
		url: API_AI_URL,
		data: {
			"query": query,
			"lang": "en",
    		"sessionId": "818d1e73-1908-4bde-9171-dd7f79b20662"
		},
		headers: {"Authorization": `Bearer ${CLIENT_KEY}`,"Content-Type": "application/json; charset=utf-8"}
	})

	return {
		type: FETCH_CHAT,
		payload: request
	};
}