import { FETCH_WEATHER } from '../actions/index'; 	

export default function(state = [], action) {

	switch(action.type){
		case FETCH_WEATHER: 
			// return state.concat([action.payload.data]); // immutable code. Never use state.push because that mutates but in React we should always send new array
			return [ action.payload.data, ...state ]; // es6 syntax
	}
	return state;
}